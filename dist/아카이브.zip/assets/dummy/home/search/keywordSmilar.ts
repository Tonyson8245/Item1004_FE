export let similarKeywords: string[] = [
  `메이플스토리`,
  `메이플스토리 M`,
  `메이플스토리 2`,
  `메이플스토리 월드`,
  `메이플스토리 메소`,
  `메이플스토리 마일리지`,
  `마왕기`,
  `마왕온라인`,
  `마왕을물리쳤다`,
  `마왕전`,
];

export default similarKeywords;
