export let gameSilmilar: string[] = [
  `메이플스토리`,
  `메이플스토리 2`,
  `메이플스토리 M`,
];

export default gameSilmilar;
