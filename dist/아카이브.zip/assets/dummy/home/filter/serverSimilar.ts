export let serverSimilar: string[] = [`크로아`];

export default serverSimilar;
